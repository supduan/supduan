<template>
	<view>
		<dyl-tabs :tabs="tabs" @tabs="HandleTabsChange"></dyl-tabs>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				tabs: [{
					id: 0,
					value: '全部',
					isActive: true
				}, {
					id: 1,
					value: '待付款',
					isActive: false
				}, {
					id: 2,
					value: '待收货',
					isActive: false
				}, {
					id: 3,
					value: '退货/退款',
					isActive: false
				}],
				header:{
					Authorization:''
				},
				orderParam: {
					type:1
				},
				orderList: []
			}
		},
		onLoad(res){
			this.HandleTabsChange(parseInt(res.num));
		},
		onShow() {
			this.getOrderList();
			const token = uni.getStorageInfoSync('token');
			this.header.Authorization=token;
		},
		methods: {
			HandleTabsChange(option) {
				this.tabs.forEach(v => v.id === option ? v.isActive = true : v.isActive = false)
			},
		}
	}
</script>

<style>

</style>
