<template>
		<view>
			<!-- 地址框 -->
			<dyl-address :address="address"></dyl-address>
			<!-- 购物车标题 -->
			<view class="cart-title">
				<text class="iconfont icon-shouye">购物车</text>
			</view>
			<!-- 购物车列表 -->
			<view class="" v-for="(item,index) in cart" :key="index">
				<dyl-goods :goodsl='item' :showNumOnly="true" @changeNum='changeNum'  @changeChecked='changeChecked'></dyl-goods>
			</view>
			<dyl-settel :cartData="cart"  :buttonText="'支付'" @handleAllChecked="handleAllChecked"></dyl-settel>
		</view>
</template>

<script>
	export default {
		data() {
			return {
				cart:[],
				address:{},
				buy: [],
			}
		},
		onShow(){
			//从缓存获取数据
			this.address = uni.getStorageSync('address') || {};
			const buy = uni.getStorageSync('buy') || {};
			if(buy.goods_id){
				this.cart = [];
				this.cart.push(buy);
				uni.removeStorageSync('buy');
			}else{
				this.cart = uni.getStorageSync('cart') || [];
				this.cart = this.cart.filter(v => v.checked);
			}
		},
		methods: {
			changeNum(e){
				let index=this.cart.findIndex(v=>v.goods_id==e.goods_id);
				if(e.cartNum === 0){
					this.cart.splice(index,1)
				}else{
				// console.log(e.cartNum);
				this.cart[index].cartNum=e.cartNum;
				
				}
				console.log(this.cart)
			}
		}
	}
</script>

<style>

</style>
