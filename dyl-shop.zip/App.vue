<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	@import url('static/iconfont/iconfont.css');
	/*每个页面公共css */
	page,view,navigator,text,navigator,swiper,seiper-item,image{
		padding: 0;
		margin: 0;
		box-sizing: border-box;
	}
	page{
		font-size: 28rpx;
		--themeColor:#000000;
		--separateLine:1rpx solid #b0b0b0
	}
</style>
