<template>
	<view class="tabs">
			<view class="tabs-nav" :class="item.isActive?'active' : '' "
			 v-for="(item,index) in tabs" :key="item.id" @click="onchangIndex(item.id)">
				{{item.value}}
		</view>
	</view>
</template>

<script>
	export default {
		name:"dyl-tabs",
		data() {
			return {
				
			}
		},
		methods:{
			onchangIndex(aid){
			this.$emit("tabsid",aid);
			}	
		},
		props:["tabs"]
	}
</script>

<style lang="scss">
	page{
		margin-top:90rpx;
	}
	.tabs{
		width: 750rpx;
		height: 90rpx;
		display: flex;
		.tabs-nav{
			flex: 1;
			display: flex;
			border-bottom: var(--separateLine);
			justify-content: space-around;
			align-items: center;
			flex-direction: row;
			&.active{
				color: #000000;
				border-bottom:5rpx solid #000000 ;
			}
		}
	}

</style>