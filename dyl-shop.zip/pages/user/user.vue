<template>
	<view v-if="token">
		<view class="top">
			<view class="user-info">
				<image class="user-image" src="../../static/tabBar1/my-active.png" mode="widthFix"></image>
				<view class="user-name">微信用户</view>
			</view>
			<view class="bottom">
				<!-- 1.我的足迹 -->
				<view class="feet">
					<view class="feet-box" v-for="(item,index) in myFeet" :key="item.id">
						<view class="num">{{item.num}}</view>
						<view class="text">{{item.text}}</view>
					</view>
				</view>
				<view class="order">
					<!-- 2.我的订单 -->
					<view class="dida">我的订单</view>
					<!-- 3.订单详情 -->
					<view class="order-box" @click="gotoOrder(0)">
						<view class="iconfont icon-dingdan-heji"></view>
						<view class="text">全部订单</view>
					</view>
					<view class="order-box"  @click="gotoOrder(1)">
						<view class="iconfont icon-fukuantongzhi"></view>
						<view class="text">待付款</view>
					</view>
					<view class="order-box"  @click="gotoOrder(2)">
						<view class="iconfont icon-daishouhuo"></view>
						<view class="text">待收货</view>
					</view>
					<view class="order-box">
						<view class="iconfont icon-fukuantongzhi" @click="gotoOrder(3)"></view>
						<view class="text">退款/退货</view>
					</view>
				</view>
				<!-- 4.收货地址 -->
				<view class="">
					<view class="address">
						<view class="text">收货地址管理</view>
						<view class="more">></view>
					</view>
					<view class="contact">
						<view class="text">联系客服</view>
						<view class="more">400-618-4000</view>
					</view>
					<view class="feetback">
						<view class="text">意见反馈</view>
						<view class="more">></view>
					</view>
					<view class="about">
						<view class="text">关于我们</view>
						<view class="more">></view>
					</view>
					<view class="exit" @tap="logout">
						<view class="text">退出登录</view>
						<view class="more">></view>
					</view>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				token: '',
				userInfo: {},
				myFeet:[{
					id:0,
					num: 0,
					text: '收藏的店铺'
				},
				{
					id:1,
					num:2,
					text: '收藏的商品'
				},
				{
					id: 2,
					num: 0,
					text: '关注的商品'
				},
				{
					id: 3,
					num: 0,
					text: '我的足迹'
				}
				]
			}
		},
		onShow(){
			this.userInfo = uni.getStorageSync('userInfo');
			this.token = uni.getStorageSync('token');
			if(!this.token){
				uni.setStorageSync('page','user');
				uni.reLaunch({
					url:'../../subpkg2/login/login'
				})
			}
		},
		methods: {
			async logout(){
				const succ = await uni.showModal({
					title:'提示',
					content:'确认退出登录吗？'
				});
				if(succ && succ.confirm){
					uni.removeStorageSync('token');
					uni.removeStorageSync('address');
					uni.removeStorageSync('userinfo');
					uni.reLaunch({
						url:'../../subpkg2/login/login'
					})
				}
			},
			gotoOrder(num){
				uni.navigateTo({
					url:'../../subpkg2/order/order?num=' + num
				})
			}
		}
	}
</script>

<style lang="scss">
	.top {
		width: 750rpx;

		.user-info {
			width: 750rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			flex-wrap: wrap;
			padding-top: 30rpx;
			background-color: #686868;

			.user-image {
				width: 150rpx;
				height: 150rpx;
				border-radius: 100%;
				background-color: #fff;
			}

			.user-name {
				width: 750rpx;
				margin-top: 30rpx;
				padding-bottom: 30rpx;
				text-align: center;
				color: #fff;
			}
		}

		.bottom {
			width: 750rpx;
			height: 900rpx;
			background-color: #e8e8e8;
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			align-items: center;

			.feet {
				width: 700rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				background-color: #fff;

				.feet-box {
					flex: 1;
					text-align: center;

					.num {
						color: #ff0000;
					}

					.text {
						color: #686868;
					}
				}
			}

			.order {
				width: 700rpx;
				display: flex;
				flex-wrap: wrap;
				justify-content: center;
				align-items: center;
				background-color: #fff;

				.dida {
					width: 700rpx;
					height: 90rpx;
					color: #686868;
					margin-top: 15rpx;
					padding-top: 10rpx;
					border-bottom: 2px solid #686868;
					background-color: #fff;
				}

				.order-box {
					flex: 1;
					padding: 20rpx 0;
					color: #686868;

					text-align: center;
				}
			}

			.address {
				width: 700rpx;
				height: 90rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				background-color: #fff;
				margin-top: 15rpx;
			}

			.contact {
				width: 700rpx;
				height: 90rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				background-color: #fff;
				border-bottom: 2px solid #686868;
				margin-top: 15rpx;
			}

			.feetback {
				width: 700rpx;
				height: 90rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-bottom: 2px solid #686868;
				background-color: #fff;
			}

			.about {
				width: 700rpx;
				height: 90rpx;
				display: flex;
				justify-content: space-between;
				align-items: center;
				background-color: #fff;
			}

			.exit {
				width: 700rpx;
				height: 90rpx;
				display: flex;
				margin-top: 15rpx;
				justify-content: space-between;
				align-items: center;
				color: #ff0000;
				background-color: #fff;
			}

		}

	}
</style>