<template>
	<view class="goods" @tap="goodsDetail" @longtap="deleteGoods">
		<view class="image-box">
			<checkbox v-if="showCheck" :checked="goodsl.checked" @click.stop="changeChecked" color="var(--themeColor)"></checkbox>
			<image :src="goodsl.goods_big_logo || defaultImg " mode="widthFix"></image>
		</view>
		<view class="goods-info">
			<view class="goods-name">{{goodsl.goods_name}}</view>
			<view class="goods-price-box">
				<view class="goods-price">￥ {{goodsl.goods_price}}</view>
				<view class="goods-num" v-if="vshowNum">
					<view class="num-edit" @tap.stop="numSub" :class="goodsl.cartNum==1 ? 'bababa' : '' " >-</view>
					<view class="num">{{goodsl.cartNum}}</view>
					<view class="num-edit" @tap.stop="numAdd" >+</view>
				</view>
				<view class="num-only" v-if="vshowNumOnly" @tap.stop="onClik">×{{goodsl.cartNum}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name:"dyl-goods",
		data() {
			return {
				defaultImg:'/../static/default_image.png',
				vshowNum:this.showNum,
				vshowNumOnly:this.showNumOnly
			};
		},
			props:['goodsl','showCheck','showNum','allowLongTa','showNumOnly'],
			// props:{
			// 	goodsl:{
			// 		type:Object,
			// 		default:null
			// 	},
			// 	showCheck:{
			// 		type:Object,
			// 		default:false
			// 	},
			// 	showNum:{
			// 		type:Object,
			// 		default:false
			// 	},
			// 	allowLongTa:{
			// 		type:Object,
			// 		default:false
			// 	},
			// 	showNumOnly:{
			// 		type:Object,
			// 		default:false
			// 	}
			// },
		methods:{
			onClik(){
				this.vshowNum=true;
				this.vshowNumOnly=false;
			},
			goodsDetail(){
				uni.navigateTo({
					url:'../../subpkg1/goods-detail/goods-detail?goods_id='+this.goodsl.goods_id
				})
			},
			changeChecked(){
				this.$emit('changeChecked',{
					goods_id:this.goodsl.goods_id,
					checked:!this.goodsl.checked
				})
			},
			numSub(){
				if(this.goodsl.cartNum >1){
					this.$emit('changeNum',{
						goods_id:this.goodsl.goods_id,
						cartNum:this.goodsl.cartNum - 1,
					})
				}
			},
			numAdd(){
					this.$emit('changeNum',{
						goods_id:this.goodsl.goods_id,
						cartNum:this.goodsl.cartNum + 1,
					})
			},
			deleteGoods(){
				if(this.allowLongTa){
					uni.showModal({
						title:'删除',
						content:'您确定要删除该商品吗？',
						success:(res)=> {
							if(res.confirm){
								this.$emit('changeNum',{
									goods_id:this.goodsl.goods_id,
									cartNum:0,
								});
							}
						}
					})
				}
			}
		}
	}
</script>

<style lang="scss">
		page{
			margin-top: 90rpx;
		}
	.goods {
		display: flex;
		padding: 15rpx;
		border-bottom: var(--separateLine);

		.image-box {
			flex: 1;
			display: flex;
			align-items: center;

			image {
				width: 80%;
			}
		}

		.goods-info {
			flex: 2;
			display: flex;
			flex-direction: column;
			justify-content: space-between;
			padding-left: 15rpx;

			.goods-name {
				/**对象作为伸缩盒子模型展示**/
				display: -webkit-box;
				/**设置或检索伸缩盒子对象的子元素的排列方式**/
				-webkit-box-orient: vertical;
				/**显示的行数**/
				-webkit-line-clamp: 2;
				/**隐藏超出的内容**/
				overflow: hidden;
			}

			.goods-price-box {
				display: flex;
				justify-content: space-between;
				border: #676767;
				border-radius: 30rpx;

				.goods-price {
					color: var(--themeColor);
					font-size: 34rpx;
				}

				.goods-num {
					width: 210rpx;
					height: 60rpx;
					display: flex;
					font-size: 36rpx;
					border: 1rpx solid #bababa;
					border-radius: 30rpx;

					.num-edit {
						flex: 1;
						//background-color: #e6e6e6;
						display: flex;
						align-items: center;
						justify-content: center;

						&.bababa{
							color: #bababa;
						}
					}
					.num {
							flex: 1;
							display: flex;
							justify-content: center;
							align-items: center;
							border-left: 1rpx solid #bababa;
							border-right: 1rpx solid #bababa;
						}

				}
					.num-only{
						font-size: 35rpx;
					}
			}
		}
	}
</style>
