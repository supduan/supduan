<template>
	<view class="login">
		<view class="box">
			<image src="../../static/tabBar1/my.png" mode="widthFix"></image>
		</view>
		<view class="login-box">
			<button type="primary" @click="getUserInfo">一键登录</button>
			<text>登录后尽享更多权益</text>
		</view>
		
	</view>
</template>

<script>
	import{
		getUserProfile,
		login
	}from '../../common/shop.js'
	export default {
		name:"gx-login",
		data() {
			return {
				
			};
		},
		methods:{
			async getUserInfo(e){
				const{
					encryptedData,
					rawData,
					iv,
					signature,
					userInfo
				} = await getUserProfile();
				// let encryptedData = '';
				// let rawData = '';
				// let iv = '';
				// let signature = '';
				// let code = '';
				// uni.getUserProfile({
				// 	desc:'weixin',
				// 	success:(res) => {
				// 		console.log(res);
				// 		encryptedData = res.encryptedData;
				// 		rawData = res.rawData;
				// 		iv = res.iv;
				// 		signature = res.signature;
						uni.setStorageSync('userInfo',userInfo);
						const{
							code
						} = await login();
						// uni.login({
						// 	success: (res1) => {
						// 		console.log(res1);
						// 		code = res1.code;
								const loginParams= {
									encryptedData,
									rawData,
									iv,
									signature,
									code
								};
							// const {token} = await	this.$Https({
							// 		url:'/users/wxlogin',
							// 		data:loginParams,
							// 		method:'post'
							// 	});
								const token = 'token';
								console.log(token);
								uni.setStorageSync('token',token);
								// .then(res2 =>{
								// 	console.log(res2);
								// }).catch(
								// 	err => {
								// 		console.log(err);
								// 	}
								// )
						// 	}
						// })
				// 	}
				// })
				let page = uni.getStorageSync('page');
				uni.removeStorageSync('page');
				if(page === 'pay'){
					uni.navigateTo({
						url:'../../subpkg2/pay/pay'
					})
				}else if(page === 'user' || 'token'){
					uni.switchTab({
						url:'../../pages/user/user'
					})
				}
			}
		}
	}
</script>

<style lang="scss">
.login{
	width: 750rpx;
	image{
		width: 150rpx;
		height: 150rpx;
		border: 1px solid #bababa;
		border-radius: 100%;
		background-color: #eaeaea;
	}
	.box{
		display: flex;
		align-items: center;
		justify-content: center;
		margin-top: 120rpx;
	}
	.login-box{
		display: flex;
		justify-content: center;
		flex-wrap: wrap;
		align-items: center;
		margin-top: 40rpx;
		button{
			width: 700rpx;
			height: 90rpx;
			color: #fff;
			background-color: #ff0000;
			border-radius: 50rpx;
		}
		text{
			padding-top: 15rpx;
			color: #797979;
		}
	}
}
</style>