<template>
	<view>
		<view v-if="cart.length>0">
		<dyl-address :address="address"></dyl-address>
		<!-- 购物车标题 -->
		<view class="cart-title">
			<text class="iconfont icon-gouwuche">购物车</text>
		</view>
		<view class="" v-for="(item,index) in cart" :key="index">
			<dyl-goods :goodsl='item' :showCheck='true' :showNum='true' @changeNum='changeNum' allowLongTa='true' @changeChecked='changeChecked'></dyl-goods>
		</view>
		<dyl-settel :cartData="cart" :showAllCheck="true" :buttonText="'结算'" @handleError="handleError"></dyl-settel>
		</view>
		<view v-else class="ss">
			<view class="box">
			<image src="../../static/优购商城图片/cart_empty.png" mode="widthFix"></image>
			</view>
			<view class="bor" ><text>空空如也~</text> </view>
		</view>
	</view>
	
</template>

<script>
	export default {
		data() {
			return {
				cart:[],
				address:{},
			}
		},
		onShow(){
			//从缓存获取数据
			this.cart=uni.getStorageSync('cart') || [];
			console.log(this.cart);
		    this.address= uni.getStorageSync('address') || {};
		},
		methods: {
			// 修改购物车相应的商品数量
			changeNum(e){
				let index=this.cart.findIndex(v=>v.goods_id==e.goods_id);
				if(e.cartNum === 0){
					this.cart.splice(index,1)
				}else{
				// console.log(e.cartNum);
				this.cart[index].cartNum=e.cartNum;
				
				}
				uni.setStorageSync('cart',this.cart);
			},
			changeChecked(e){
				let index=this.cart.findIndex(v=>v.goods_id==e.goods_id);
				this.cart[index].checked=e.checked;
				uni.setStorageSync('cart',this.cart);
				console.log(this.cart);
			},
			handleError(e){
				this.cart.forEach(v=>v.checked=e);
			}
		}
	}
</script>

<style lang="scss">
	.cart-title {
		padding: 30rpx;
		font-size: 30rpx;
		border-bottom: var(--separateLine);
	}
	.box{
		width: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
		padding-top: 50rpx;
		image{
			width: 400rpx;
			border-radius: 50rpx;
		}
	}
	.bor{
		display: flex;
		justify-content: center;
		align-items: center;
		text{
			color: #8f8f8f;
			font-size: 40rpx;
		}
	}
</style>
