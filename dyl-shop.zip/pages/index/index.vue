<template>
	<view class="index">
		<dyl-header></dyl-header>
		<!-- 轮播图 -->
		<view class="index-swiper">
			<swiper class="swiper" indicator-dots="true" autoplay="true" interval="3000"duration="1000">
				<swiper-item v-for="(item,index) in swiperlist" :key="index">
					<image :src="item.image_src" mode="widthFix"></image>
				</swiper-item>
			</swiper>
		</view>
					<!-- 导航 -->
		<view class="index-cate" >
			<view class="image_cate" >
					<view class="img_box" v-for="(item,index) in navigator":key="index">
						<image :src="item.image_src" mode="widthFix"></image>
					</view>	
			</view>
			</view>
			<!-- 楼层 -->
			<view class="index_floor">
				<view class="floor_group "  v-for="(item,index) in flootlsit">
					<view class="floor_title">
							<image :src="item.floor_title.image_src" mode="widthFix"></image>
					</view>
					<view class="floor_list" >
						<view class="image_box" v-for="(list,index2) in item.product_list" :key="index2">
							<image :src="list.image_src" mode="scaleToFill"></image>
						</view>
					</view>
				</view>
			</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				swiperlist:[],
				navigator:[],
				flootlsit:[]
			}
		},
		onLoad() {
			this.getswiperlist();
			this.getNavigator();
			this.getFlootdata();
		},
		methods: {
			
			// async 异步 await等待
			//轮播图
			async getswiperlist(){
				const res= await this.$Https({
					url:'/home/swiperdata'
				});
					console.log(res);
					this.swiperlist=res.message;
			},
			//导航
			async getNavigator(){
				const res= await this.$Https({
					url:'/home/catitems'
				});
					console.log(res);
					this.navigator=res.message;
			},
			//楼层
			async getFlootdata(){
				const res= await this.$Https({
					url:'/home/floordata'
				});
				console.log(res);
				this.flootlsit=res.message;
			},

		}
	}
</script>

<style lang="scss">
	.index{
		
		.index-swiper{
		margin-top: 90rpx;
			.swiper{ 
				image{
					width: 750rpx;
					}
				}
		}
		.index-cate{
			.image_cate{
				display: flex;
				padding: 10rpx;
				.img_box{
						flex: 1;
						image{
							width: 100%;
						}
				}
				}

		}
		.index_floor{
			width: 750rpx;
			.floor_title{
				image{
					width: 100%;
				}
			}
			.floor_list{
				padding: 15rpx;
				.image_box{
					width: 240rpx;
					height: calc(240rpx * 386 / 232);
					float: left;
					
					//计算最后四个图片的高宽
					&:nth-last-child(-n+4){
						height: calc(240rpx * 386 / 232 / 2);
						border-left: 10rpx solid #ffffff;
					}
					//第2、3张图片的下边框
					&:nth-child(2), &:nth-child(3){
						border-bottom: 10rpx solid #ffffff;
					}
					image{
						width: 100%;
						height: 100%;
					}
				}
			}
		}

	}
</style>

				