<template>
	<view class="header">
		<navigator url="../../subpkg1/search/search">
			<text class="search iconfont icon-sousuo">搜索</text>
		</navigator>
	</view>
</template>

<script>
	export default {
		name:"gx-header",
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">
	.header{
		width: 750rpx;
		height: 90rpx;
		background-color: #ff0000;
		display: flex;
		justify-content: center;
		align-items: center;
		position: fixed;
		left: 0;
		top: var(--window-top);
		z-index: 10;
		
			.search{
				width: 720rpx;
				height: 60rpx;
				background-color: #fff;
				border-radius: 20rpx;
				display: flex;
				justify-content: center;
				align-items: center;
			}
	}

</style>