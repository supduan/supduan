<template>
	<view class="">
		<dyl-header></dyl-header>
		<dyl-tabs :tabs="tabsList" @tabsid="changfor"></dyl-tabs>
		<!-- <lqc-goods v-for="(item,index) in goodlist" :goodsl="item"></lqc-goods> -->
		<dyl-goods v-for="(item,index) in newGoodsList" :goodsl="item"></dyl-goods>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				tabsList:[
				{
					id:0,
					value:"综合",
					isActive:true
				},
				{
					id:1,
					value:"价格▲",
					isActive:false
				},
				{
					id:2,
					value:"价格▼",
					isActive:false
				},
				],
				querypag:{
					query:'',
					cid:'',
					pagenum:1,
					pagesize:10
				},
				goodlist:[],
				totaPageCount:1,
				isloading:false // 是否正在请求数据
			}
		},
		onLoad(e) {
			this.querypag.cid=e.cid;
			this.getGoodslist();
		},
		//页面上拉加载
		//onReachBottom页面滚动到底部的事件
		onReachBottom(){
			// 判断是否还有下一页的数据 如当前页码大于总页数，则没有下一页
			if(this.querypag.pagenum >= this.totaPageCount) return uni.showToast({
				title:"我也是有底线的"
			});
			//判断是否正在请求其它数据 ，如果有，则不额外发起请求
			if(this.isloading) return;
			// 获取下一页数据
			this.querypag.pagenum++;
			this.getGoodslist();
			
		},
		//下拉刷新
		onPullDownRefresh(){
			//重置数据
			this.goodlist=[];
			this.querypag.pagenum=1;
			// 重新发请求
			setTimeout(()=>{
				// 数据请求成功后去掉刷新 下拉后让它消失
				this.getGoodslist(()=>uni.stopPullDownRefresh());
			},1000)
		},
		methods: {
			// 获取商品列表
			async getGoodslist(cd){
				// 打开节流阀
				this.isloading=true;
				 const res=await this.$Https({
					 url:'/goods/search',
					 data:this.querypag
				 });
				 console.log(res);
				 // this.goodlist=res.message.goods;
				// 关闭节流阀
				this.isloading=false;
				//只要数据请求完毕，就立即调用cd 回调函数
				cd && cd();
				// 计算总页数
				 this.totaPageCount=Math.ceil(res.message.total/this.querypag.pagenum);
				// 通过扩展运算符的形式，进行新旧数据的拼接
				 this.goodlist=[...this.goodlist,...res.message.goods];
				 console.log(this.goodlist);
			},
			//切换选项卡
			changfor(aid){
				this.tabsList.forEach(v=> v.id==aid ? v.isActive=true: v.isActive=false);
			}
			
		},
		computed:{
			newGoodsList(){
				// 正则排序
				function compare(arg){
					return function(a,b){
						return a[arg]-b[arg];
					}
				}
				
				if(this.tabsList[0].isActive){
					return this.goodlist;
				}else if(this.tabsList[1].isActive){
					// 正则排序
					this.goodlist.sort(compare('goods_price'));
					return this.goodlist;
				}else {
					// 正则排序
					this.goodlist.sort(compare('goods_price'));
					// 返转
					this.goodlist.reverse();
					return this.goodlist;
				}
			}
		
		}
	}
</script>

<style lang="scss">
	page{
		margin-top: 90rpx;
	}

	
	
</style>
