<template>
	<view class="">
		<dyl-header></dyl-header>
		<!-- 左 -->
		<view class="scroll_all">
			<scroll-view scroll-y="true" class="scroll_left">
				<view  class="scroll_title " :class="index===currentIndex?'active' : '' " v-for="(item,index) in leftMenulist" 
				:key="index" @tap="changeIndex(index)" > 
					{{item}}
				</view>
			</scroll-view>
			<!-- 右 -->
			<scroll-view scroll-y="true" class="scroll_right">
				<view class="goods_group" v-for="(item,index) in rightData" :key="item.cat_id">
					<view class="goods_title">/{{item.cat_name}}/</view>
					<view class="goods_list">
						<navigator class="image_box" :url="'../../subpkg1/goods-list/goods-list?cid='+item1.cat_id" v-for="(item1,index) in item.children" :key="item1.cat_id">
							<image :src="item1.cat_icon" mode="widthFix"></image>
							<text>{{item1.cat_name}}</text>
						</navigator>
					</view>
				</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				categoryList:[],
				leftMenulist:[],
				rightData:[],
				currentIndex:0
			}
		},
		onLoad(){
			const Cates = uni.getStorageSync('cates');
			if(!Cates){
				this.getCategory();
			}else{
				if((Date.now() - Cates.time) > 1000 * 10){
					this.getCategory();
				}else{
					console.log('使用旧数据');
					this.categoryList=Cates.data;
					//左侧 大菜单数据
					this.leftMenulist=this.categoryList.map(e => e.cat_name)
					// console.log(this.leftMenulist);
					//右侧数据
					this.rightData=this.categoryList[0].children;
					// console.log(this.rightData);
				}
			}
			
		},
		methods: {
		async	getCategory(){
					const res= await this.$Https({
						url:'/categories'
					});
						// console.log(res);
						this.categoryList=res.message;
						console.log(this.categoryList);
					
					try{
						//数据缓存  同步
						uni.setStorageSync('cates',{
							time:Date.now(),
							data:this.categoryList
						});
					}catch(e){
						uni.showToast({
							title:'数据缓存失败',duration:2000
						})
					}
					//左侧 大菜单数据
					this.leftMenulist=this.categoryList.map(e => e.cat_name)
					// console.log(this.leftMenulist);
					//右侧数据
					this.rightData=this.categoryList[0].children;
					// console.log(this.rightData);
			},
			changeIndex(index){
				this.currentIndex=index;
				this.rightData=this.categoryList[index].children;
				// console.log(this.rightData);
				// console.log(this.currentIndex);
			}
		}
	}
</script>

<style lang="scss">
	page{
		margin-top: 90rpx;
	}
	.scroll_all{
		height: calc(100vh - 90rpx);
		display: flex;
		.scroll_left{
			flex:2;
			.scroll_title{
				height: 90rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				background-color: #f8f8f8;
				border-bottom: var(--separateLine);
				
				&.active{
					color: var(--themeColor);
					border-left:5rpx solid var(--themeColor) ;
					background-color: #ffffff;
				}
			}
		}
		.scroll_right{
			flex:5;
			.goods_group{
				.goods_title{
					height: 90rpx;
					display: flex;
					align-items: center;
					justify-content: center;
				}
				.goods_list{
					display: flex;
					flex-wrap: wrap;
					.image_box{
						width: 33.33%;
						display: flex;
						flex-direction: column;
						align-items: center;
						image{
							width: 70%;
						}
						text{
							margin-bottom: 10rpx;
						}
					}
				}
			}
			
		}
	}
</style>
