<template>
	<view class="cart-tool">
		<view class="tool-selectAll" v-if="showAllCheck">
			<checkbox-group @change="changeallChecked">
				<label>
					<checkbox color="var(--themeColor)" :checked="allChecked"/>
					<text>全选</text>
				</label>
			</checkbox-group>
		</view>
		<view class="total-price-box">
			<view class="total-price">合计：<text class="price-text">￥{{totalPrice}}</text></view>
			<view class="runway-text">包含运费</view>
		</view>
		<view class="settle" @tap="gotoPay">{{buttonText}}({{totalNum}})</view>
	</view>
</template>

<script>
import { handleError } from "vue";
	export default {
		name:"gx-settel",
		data() {
			return {
				
			};
		},
		props:{
			cartData:{
				type:Array,
				default:[]
			},
			showAllCheck:{
				type:Boolean,
				default:false
			},
			buttonText:{
				type:String,
				default:'结算'
			}
		},
		computed:{
			//计算合计
			totalPrice(){
				let sum =0 ;
				this.cartData.forEach(v=>{
					if(v.checked){
					sum +=v.goods_price * v.cartNum;
					}
				});
				return sum;
			},
			//计算产品数量
			totalNum(){
				let num=0;
				this.cartData.forEach(v=>{
					if(v.checked){
						num +=v.cartNum;
					}
				})
				return num;
			},
			//根据所有产品的选中状态（true或false）计算出全选按钮的选中状态
			allChecked(){
				return this.cartData.every(v=>v.checked)
			}
		},
		methods:{
			changeallChecked(){
				this.$emit('handleError',!this.allChecked);
			},
			gotoPay(){
				if(this.buttonText == '结算'){
					const address = uni.getStorageSync('address');
					if(!address.userName) return uni.showToast({
						title:'没有选择地址'
					})
					if(this.totalNum == 0) return uni.showToast({
						title:'没有选择商品'
					})
					uni.navigateTo({
						url:'/subpkg2/pay/pay',
					})
				}
				 if(this.buttonText == '支付'){
					try{
						const token = uni.getStorageSync('token');
						if (!token){
							uni.setStorageSync('page','pay');
							uni.navigateTo({
								url:'/subpkg2/login/login',
							})
							return;
						}
						uni.showToast({
								title:'支付成功',
								icon:'none'
							});
							const buy = uni.getStorageSync('buy') || {};
							if(buy.goods_id){
								uni.removeStorageSync('buy');
							}else{
								let cart = uni.getStorageSync('cart') || [];
								cart = cart.filter(v => !v.checked);
								uni.setStorageSync('cart',cart);
							}
							uni.reLaunch({
								url:'../../subpkg2/order/order'
							})
						}
						catch(e){
							uni.showToast({
								title:'支付失败',
								icon:'none'
							});
							console.log(err)
						}
					}	
				}	
		}
	}
</script>

<style lang="scss">
	.cart-tool{
		width: 750rpx;
		position: fixed;
		z-index: 10;
		bottom:100rpx;
		left:0;
		display: flex;
		.tool-selectAll{
			flex: 1;
			display: flex;
			justify-content: center;
			align-items: center;
		}
		.total-price-box{
			flex: 2;
			display: flex;
			flex-direction: column;
			align-items: flex-end;
			justify-content: space-evenly;
			.total-price{
				font-size: 35rpx;
				font-weight: bold;
				.price-text{
					color: #000000;
				}
			}
			.runway-text{
				color:#b0b0b0;
			}
		}
		.settle{
			flex: 2;
			height:120rpx;
			font-size: 40rpx;
			color:#ffffff;
			background-color:#ff0000;
			display:flex;
			align-items: center;
			justify-content: center;
		}
	}
</style>