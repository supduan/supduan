export const getSetting = () => {
	return new Promise((resolve, reject) => {
		uni.getSetting({
			success: (res) => {
				resolve(res);
			},
			fail: (err) => {
				reject(err);
			}
		})
	});
}
export const openSetting = () => {
	return new Promise((resolve, reject) => {
		uni.openSetting({
			success: (res) => {
				resolve(res);
			},
			fail: (err) => {
				reject(err);
			}
		})
	});
}
export const chooseAddress = () => {
	return new Promise((resolve, reject) => {
		uni.chooseAddress({
			success: (res) => {
				resolve(res);
			},
			fail: (err) => {
				reject(err);
			}
		})
	});
}

export const login = () => {
	return new Promise((resolve, reject) => {
		uni.login({
			success: (res) => {
				resolve(res);
			},
			fail: (err) => {
				reject(err);
			}
		})
	});
}
export const getUserProfile = () => {
	return new Promise((resolve, reject) => {
		uni.getUserProfile({
			desc: 'weixin', // 这个参数是必须的
			success: res => {
				resolve(res);
			},
			fail: (err) => {
				reject(err);
			}
		})
	});
}