<template>
	<view class="goods-detail">
		<!-- 轮播图 -->
		<view class="goods-detail-swiper">
			<swiper class="swiper" indicator-dots="true" autoplay="true" interval="3000"duration="1000">
				<swiper-item v-for="(item,index) in goodsInfo.pics" :key="index">
					<image :src="item.pics_sma" mode="aspectFit"></image>
				</swiper-item>
			</swiper>
		</view>		
		<!-- //价格 -->
		<view class="goods_price">￥{{goodsInfo.goods_price}}</view>
		<!-- //商品信息 -->
		<view class="goods_name_all">
				<view class="goods_name">
					{{goodsInfo.goods_name}}
				</view>
				<view class="goods_shoucang">
					<text class="search iconfont icon-shoucang"></text>
					<text>收藏</text>
				</view>
		</view>
		<!-- //图文详情 -->
		<view class="goods_introduce">
			<text class="goods_introduce_text">图文详情</text>
			<rich-text :nodes="goodsInfo.goods_introduce"></rich-text>
		</view>
		<!-- 工具栏 -->
		<view class="toolbar">
				<view class="tool-item">
					<text class=" iconfont ">&#xe625;</text>
					<text>客服</text>
					<button type="default" open-type="contact"></button>
				</view>
			<view class="tool-item">
				<text class="iconfont ">&#xe86e;</text>
				<text>分享</text>
				<button type="default" open-type="share"></button>
			</view>
			<view class="tool-item" @tap="gotoCart">
				<text class=" iconfont ">&#xe600;</text>
				<text>购物车</text>
			</view>
				<view class="common boolbar_guc" @tap="addCart">
					<text>加入购物车</text>
				</view>
				<view class="common boolbar-pay" @tap="buy">
					<text>立即购买</text>
				</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				 //向服务器接口发起请求时发送的数据
				queryParam:{
					goods_id:0
				},
				goodsInfo:[]//商品信息
			}
		},
		// onLoad参数为上一个页面传递的数据。参数为Object（用于页面传参）
		onLoad(e){
			this.queryParam.goods_id=e.goods_id;
			this.getGoodsInfo();
		},
		methods: {
			async getGoodsInfo(){
				const res =await this.$Https({
					url:'/goods/detail',
					data:this.queryParam //向服务器接口发起请求时发送的数据
				});
				// console.log(res);
				this.goodsInfo=res.message;
				console.log(this.goodsInfo);
			},
		gotoCart(){
			uni.switchTab({
				url:'../../pages/cart/cart'
			})
		},
		addCart(){
				//从本地缓存中取出购物车  数组类型
				let cart=uni.getStorageSync('cart') || [];
				//从购物车中查询是否已加入该商品
				let index=cart.findIndex(v=>v.goods_id==this.goodsInfo.goods_id)
			
				//然如果没有，将该商品加入，并添加数量和选中状态属性
				if(index==-1){
					this.goodsInfo.cartNum=1;
					this.goodsInfo.checked=true;
					cart.push(this.goodsInfo);
				} else {
					//如果有，将该商品数量+1
					cart[index].cartNum++;
				}
				//将购物车数据写入缓存中
				uni.setStorageSync('cart',cart);
				//弹出信息
				uni.showToast({
					title:"加入成功"
				});
				//打印购物车数据
				console.log(cart);
			},
			buy(){
				this.goodsInfo.cartNum = 1;
				this.goodsInfo.checked=true;
				uni.setStorageSync('buy',this.goodsInfo);
				uni.navigateTo({
					url:'../../subpkg2/pay/pay'
				})
			}
		}
	}
</script>

<style lang="scss">
	page{
		padding-bottom:120rpx;
	}
	.goods-detail{
		.goods-detail-swiper{
			.swiper{
				height: 500rpx;
				image{
					width: 750rpx;
					// height: 80%;		
					align-items: center;
					justify-content: center;
							}
			}
		}
		.goods_price{
			font-size: 50rpx;
			margin: 20rpx 20rpx;
			color: var(--themeColor);
		}
		.goods_name_all{
			display: flex;
			padding: 20rpx 10rpx;
			margin-right: 10rpx;
			border-bottom: 6rpx solid #c6c6c6;
			.goods_name{
				flex: 7;
			}
			.goods_shoucang{
				display: flex;
				flex-direction: column;
				align-items: center;
				flex: 1;
				border-left: 4rpx solid #868686;
			}
		}
		.goods_introduce{
			margin: 20rpx 0rpx;
			.goods_introduce_text{
				font-size: 50rpx;
				margin: 30rpx 20rpx;
				color: var(--themeColor);
			}
		}
		.toolbar{
			width: 750rpx;
			height: 120rpx;
			position: fixed;
			z-index: 10;
			bottom:0rpx;
			left:0;
			display:flex;
			background-color:#ffffff;
			
				.tool-item{
					flex:1;
					display:flex;
					flex-direction: column;
					align-items: center;
					position: relative;
					justify-content: center;
					border-left: 1rpx solid #c6c6c6;
					button{
						width: 70%;
						height: 100%;
						margin: 0 20%;
						position: absolute;
						top: 0;
						left: 0;
						opacity: 0;
					}
				}
			
			
			.common{
				height:120rpx;
				felx:2;
				display:flex;
				align-items: center;
				flex-direction: row;
				font-weight: bold;
			}
			.boolbar-pay{
				height:120rpx;
				width: 200rpx;
				color:#fff;
				background-color:#ff0000;
				display:flex;
				align-items: center;
				justify-content: center;
			}
			.boolbar_guc{
				height:120rpx;
				width: 200rpx;
				color:#ffffff;
				background-color:#ffaa00;
				display:flex;
				align-items: center;
				justify-content: center;
			}
		}
	}
</style>
