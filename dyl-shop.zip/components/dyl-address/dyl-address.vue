<template>
	<view class="address">
		<!-- 选择收货地址 -->
		<!-- <view class="address-button" v-if="JSON.stringify(address) === '{}'"> -->
		<view class="address-button" v-if="!address.userName">
			<button type="primary" @click="getAddress" size="mini" open-type="openSetting">+添加收货地址</button>
		</view>

		<!-- 渲染收货信息 -->
		<view class="address-info" v-else @tap="getAddress">
			<view class="name-phone">
				<view class="username">
					收货人：{{address.userName}}
				</view>
				<view class="phone">
					电话：{{address.telNumber}}
					<uni-icons type="arrowright" size="16"></uni-icons>
				</view>
			</view>
			<view class="address">
				收货地址：{{addstr}}
			</view>
		</view>
		<image src="../../static/优购商城图片/cart_border@2x.png" mode="scaleToFill"></image>
	</view>
</template>

<script>
	export default {
		name: "gx-address",
		data() {
			return {
				address: uni.getStorageSync('address') || {}
			};
		},
		props:['address'],
		computed: {
			//拼接 收获地址
			addstr() {
				if(!this.address.provinceName) return ''
				return this.address.provinceName +this.address.cityName+this.address.countyName +this.address.detailInfo
			}
		},
		onLoad() {
			this.getAddress();
		},
		methods: {
			async getAddress() {
				//1.获取微信收货地址
				//返回值res 是一个数组，第 1 项为错误对象，第 2 项为成功之后的收货地址对案
				const  succ = await uni.chooseAddress();
				console.log(succ);
				// 用户成功的选择了收货地址
				if (succ && succ.errMsg === 'chooseAddress:ok') {
					this.address = succ;
					uni.setStorageSync('address',this.address);
				}
				// 3，用户没有培权
				if (err && err.errMsg === 'chooseAddress:fail auth deny') {
					// this.reAuth(); // 调 this.reAuth() 万法，向用户重新发起投申谓
				}

			}
		},
	}
</script>

<style lang="scss">
	.address {

		.address-button {
			position: fixed;
			z-index: 10;
			height: 120rpx;
			width: 750rpx;
			left: 0rpx;
			top: var(--window-top);
			display: flex;
			justify-content: center;
			align-items: center;

			button {

				background-color: #aaffff;
			}
		}

		.address-info {
			position: fixed;
			z-index: 10;
			height: 120rpx;
			width: 750rpx;
			left: 0rpx;
			top: var(--window-top);
			padding: 10rpx;

			.name-phone {
				display: flex;
				margin: 10rpx;

				.username {
					flex: 1;
				}

				.phone {
					flex: 1;

				}
			}

			.address {}
		}

		image {
			height: 10rpx;
			width: 750rpx;
		}
	}
</style>